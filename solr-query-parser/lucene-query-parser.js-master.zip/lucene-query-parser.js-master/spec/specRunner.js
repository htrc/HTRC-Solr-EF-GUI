require.config({
  paths: {
    'jasmine': '../node_modules/jasmine/lib/jasmine',
  },
});

require(['./lucene-query-parser.spec.js']);